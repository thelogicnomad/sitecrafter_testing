import React, { useState } from 'react';
import { Search, Filter, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { Container } from '@/components/ui/Container';
import { Section } from '@/components/ui/Section';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { CourseCard } from '@/components/features/CourseCard';

const CATEGORIES = ['All', 'Technology', 'Business', 'Arts', 'Science', 'Medicine', 'Law'];

const MOCK_COURSES = [
  {
    id: '1',
    title: 'Advanced Software Engineering',
    category: 'Technology',
    instructor: 'Dr. Ramesh Kumar',
    rating: 4.9,
    students: 1240,
    image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=600&fit=crop',
    price: '₹12,000',
    duration: '12 Weeks'
  },
  {
    id: '2',
    title: 'Sustainable Architecture',
    category: 'Arts',
    instructor: 'Ar. Priya Sharma',
    rating: 4.8,
    students: 850,
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop',
    price: '₹15,500',
    duration: '10 Weeks'
  },
  {
    id: '3',
    title: 'Digital Marketing Excellence',
    category: 'Business',
    instructor: 'Sanjay Hegde',
    rating: 4.7,
    students: 2100,
    image: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=600&fit=crop',
    price: '₹8,999',
    duration: '8 Weeks'
  },
  {
    id: '4',
    title: 'Modern Psychology Foundations',
    category: 'Science',
    instructor: 'Dr. Sarah Mitchell',
    rating: 4.9,
    students: 1500,
    image: 'https://images.unsplash.com/photo-1576089172869-4f5f6f315620?w=800&h=600&fit=crop',
    price: '₹10,500',
    duration: '10 Weeks'
  },
  {
    id: '5',
    title: 'Corporate Law Essentials',
    category: 'Law',
    instructor: 'Adv. Rajesh Varma',
    rating: 4.6,
    students: 920,
    image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop',
    price: '₹18,000',
    duration: '14 Weeks'
  },
  {
    id: '6',
    title: 'Medical Ethics & Practice',
    category: 'Medicine',
    instructor: 'Dr. Anita Desai',
    rating: 4.8,
    students: 750,
    image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800&h=600&fit=crop',
    price: '₹22,000',
    duration: '16 Weeks'
  }
];

export const CourseCatalogPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredCourses = MOCK_COURSES.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.instructor.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-20 pb-12">
      <Section>
        <Container>
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Course Catalog</h1>
            <p className="text-lg text-gray-600">Explore our wide range of professional courses designed for your career growth.</p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                placeholder="Search courses, instructors..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filters
              </Button>
              <Button variant="outline" className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Sort By
                <ChevronDown className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2 mb-10">
            {CATEGORIES.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                className="cursor-pointer px-4 py-2 text-sm transition-colors hover:bg-primary/10"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>

          {/* Course Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.length > 0 ? (
              filteredCourses.map((course) => (
                <CourseCard key={course.id} {...course} />
              ))
            ) : (
              <div className="col-span-full text-center py-20">
                <div className="mb-4">
                  <Search className="h-12 w-12 text-gray-300 mx-auto" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No courses found</h3>
                <p className="text-gray-500 mb-6">We couldn't find any courses matching your search criteria.</p>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                  }}
                >
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </Container>
      </Section>
    </div>
  );
};

export default CourseCatalogPage;