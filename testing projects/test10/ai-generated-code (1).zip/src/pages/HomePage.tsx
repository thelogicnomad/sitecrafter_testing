import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, BookOpen, GraduationCap, Users, Award } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Container } from '@/components/ui/Container';
import { Section } from '@/components/ui/Section';
import { Aurora } from '@/components/ui/Aurora';
import { SplitText } from '@/components/ui/SplitText';
import { CourseCard } from '@/components/features/CourseCard';

const stats = [
  { label: 'Enrolled Students', value: '50,000+', icon: Users },
  { label: 'Academic Programs', value: '120+', icon: BookOpen },
  { label: 'Expert Faculty', value: '1,200+', icon: GraduationCap },
  { label: 'Global Rankings', value: 'Top 10', icon: Award },
];

const featuredCourses = [
  {
    id: '1',
    title: 'Advanced Software Engineering',
    category: 'Technology',
    instructor: 'Dr. Ramesh Kumar',
    rating: 4.9,
    students: 1240,
    image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=600&fit=crop',
    price: '₹12,000',
    duration: '12 Weeks'
  },
  {
    id: '2',
    title: 'Sustainable Architecture',
    category: 'Design',
    instructor: 'Ar. Priya Sharma',
    rating: 4.8,
    students: 850,
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop',
    price: '₹15,500',
    duration: '10 Weeks'
  },
  {
    id: '3',
    title: 'Digital Marketing Excellence',
    category: 'Business',
    instructor: 'Sanjay Hegde',
    rating: 4.7,
    students: 2100,
    image: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=600&fit=crop',
    price: '₹8,999',
    duration: '8 Weeks'
  }
];

const HomePage = () => {
  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-slate-900">
        <Aurora color="rgba(27, 69, 146, 0.4)" />
        <Container className="relative z-10">
          <div className="max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <SplitText 
                text="Empowering Karnataka's Future Through Education"
                className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6"
              />
            </motion.div>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl lg:text-2xl text-slate-300 mb-10 max-w-2xl"
            >
              Access world-class learning resources, expert faculty, and a vibrant academic community dedicated to excellence in the heart of India's Silicon Valley.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-wrap gap-4"
            >
              <Button size="lg" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 h-14 text-lg">
                Explore Programs
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white/20 hover:bg-white/10 h-14 text-lg">
                View Admissions
              </Button>
            </motion.div>
          </div>
        </Container>
      </section>

      {/* Stats Section */}
      <Section className="bg-white">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex flex-col items-center text-center p-6 rounded-2xl bg-slate-50 border border-slate-100"
            >
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                <stat.icon className="w-6 h-6 text-indigo-600" />
              </div>
              <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-1">{stat.value}</div>
              <div className="text-sm md:text-base text-slate-600 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Featured Courses Section */}
      <Section className="bg-slate-50">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">
              Featured Academic Programs
            </h2>
            <p className="text-lg text-slate-600">
              Discover our most popular courses designed by industry experts and top-tier academicians to accelerate your career.
            </p>
          </div>
          <Button variant="ghost" className="text-indigo-600 font-semibold group">
            View All Courses <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredCourses.map((course) => (
            <CourseCard key={course.id} {...course} />
          ))}
        </div>
      </Section>

      {/* Testimonials */}
      <Section className="bg-slate-900 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-indigo-600/10 blur-3xl rounded-full translate-x-1/2" />
        <div className="relative z-10 text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">What Our Students Say</h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            Hear from the thousands of successful graduates who have transformed their lives through Karnataka Education Nexus.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {[
            {
              quote: "The quality of faculty and the modern curriculum at Karnataka Education Nexus surpassed my expectations. It provided the perfect bridge to my first job in tech.",
              author: "Ananya Rao",
              role: "Software Engineer at Infosys",
              img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
            },
            {
              quote: "Comprehensive learning materials and a supportive community. The admissions process was seamless, and the career counseling helped me find my true passion.",
              author: "Karthik Gowda",
              role: "Architecture Graduate",
              img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop"
            }
          ].map((testimonial, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 p-8 rounded-2xl"
            >
              <p className="text-slate-300 text-lg italic mb-8">"{testimonial.quote}"</p>
              <div className="flex items-center gap-4">
                <img src={testimonial.img} alt={testimonial.author} className="w-12 h-12 rounded-full object-cover" />
                <div>
                  <div className="text-white font-bold">{testimonial.author}</div>
                  <div className="text-slate-400 text-sm">{testimonial.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>
    </div>
  );
};

export default HomePage;