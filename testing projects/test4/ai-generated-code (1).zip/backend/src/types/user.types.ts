export interface UpdateUserRequest {
    firstName?: string;
    lastName?: string;
}