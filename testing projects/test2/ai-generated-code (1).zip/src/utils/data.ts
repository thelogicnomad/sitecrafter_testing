export const products = [
      { id: 1, name: "Velvet Red Cake", price: 25.00, image: "https://images.unsplash.com/photo-1616040011494-118843477163?q=80&w=800", category: "Cakes" },
      { id: 2, name: "Chocolate Croissant", price: 4.50, image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?q=80&w=800", category: "Pastries" },
      { id: 3, name: "Sourdough Bread", price: 7.00, image: "https://images.unsplash.com/photo-1533087353985-3eac7353907c?q=80&w=800", category: "Breads" },
      { id: 4, name: "Macaron Selection", price: 12.00, image: "https://images.unsplash.com/photo-1558326567-98ae2405596b?q=80&w=800", category: "Sweets" },
      { id: 5, name: "Blueberry Muffin", price: 3.75, image: "https://images.unsplash.com/photo-1599785209707-a456fc1337bb?q=80&w=800", category: "Pastries" },
      { id: 6, name: "Strawberry Tart", price: 6.50, image: "https://images.unsplash.com/photo-1605333192425-4203531b35e2?q=80&w=800", category: "Tarts" },
      { id: 7, name: "Cinnamon Roll", price: 5.00, image: "https://images.unsplash.com/photo-1527230491136-7c05b078e0e4?q=80&w=800", category: "Pastries" },
      { id: 8, name: "Lemon Drizzle Loaf", price: 15.00, image: "https://images.unsplash.com/photo-1542528180-a37a54a86563?q=80&w=800", category: "Cakes" },
      { id: 9, name: "Baguette", price: 3.00, image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=800", category: "Breads" },
      { id: 10, name: "Cheesecake Slice", price: 8.00, image: "https://images.unsplash.com/photo-1565564239290-788736a23a3a?q=80&w=800", category: "Cakes" },
      { id: 11, name: "Almond Pretzel", price: 4.75, image: "https://images.unsplash.com/photo-1618378763361-1224793f6c69?q=80&w=800", category: "Pastries" },
      { id: 12, name: "Focaccia Bread", price: 9.50, image: "https://images.unsplash.com/photo-1621324734335-e6b97b0a7a2a?q=80&w=800", category: "Breads" },
    ];

    export const teamMembers = [
      { name: "Juliette Dubois", role: "Head Pastry Chef", image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=600" },
      { name: "Leo Chen", role: "Sourdough Specialist", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600" },
      { name: "Aisha Khan", role: "Cake Decorator", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=600" },
      { name: "Marco Rossi", role: "Barista", image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=600" },
      { name: "Chloe Kim", role: "Chocolatier", image: "https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?q=80&w=600" },
      { name: "Sam Jones", role: "Operations Manager", image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?q=80&w=600" },
      { name: "Isabella Garcia", role: "Customer Service", image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=600" },
      { name: "Ben Carter", role: "Apprentice Baker", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600" },
    ];