// Placeholder for global types. Can be expanded as needed.
    export interface Testimonial {
        id: number;
        name: string;
        quote: string;
        avatar: string;
    }