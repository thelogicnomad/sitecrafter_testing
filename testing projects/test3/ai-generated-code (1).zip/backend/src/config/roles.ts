import { UserRole } from '../types/user.types';

export const ROLES: UserRole[] = ['STUDENT', 'FACULTY', 'ADMIN'];