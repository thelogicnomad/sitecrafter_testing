/** @type {import('tailwindcss').Config} */
    import { fontFamily } from 'tailwindcss/defaultTheme';
    
    export default {
      content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
      theme: {
        extend: {
          colors: {
            background: 'hsl(220, 15%, 95%)', // Off-White Canvas
            foreground: 'hsl(0, 0%, 15%)', // Text/Shadows
            primary: 'hsl(340, 50%, 30%)', // Deep Burgundy
            accent: 'hsl(45, 100%, 75%)', // Soft Gold
          },
          fontFamily: {
            sans: ['"Inter"', ...fontFamily.sans],
            serif: ['"Playfair Display"', ...fontFamily.serif],
          },
          keyframes: {
            shake: {
              '0%, 100%': { transform: 'translateX(0)' },
              '10%, 30%, 50%, 70%, 90%': { transform: 'translateX(-5px)' },
              '20%, 40%, 60%, 80%': { transform: 'translateX(5px)' },
            },
          },
          animation: {
            shake: 'shake 0.5s ease-in-out',
          },
        },
      },
      plugins: [require('tailwindcss-animate')],
    };